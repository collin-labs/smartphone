import LinkedInApp from "@/components/LinkedInApp";

export default function Home() {
  return (
    <div style={{
      width: "100vw",
      height: "100vh",
      background: "#111",
      display: "flex",
      alignItems: "center",
      justifyContent: "center",
    }}>
      <div style={{
        width: 455,
        height: 860,
        borderRadius: 32,
        overflow: "hidden",
        border: "3px solid #333",
        position: "relative",
        background: "#000",
      }}>
        <LinkedInApp />
      </div>
    </div>
  );
}
